package com.kevin.chegesalon;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;

public class BookSalonist extends AppCompatActivity {
    private AdView mAdView;
    private InterstitialAd mInterstitialAd;

    GridView androidGridView;

    String[] gridViewString = {
            "Person", "Bike", "Sun", "Website", "Profile", "WordPress",
            "Person", "Bike", "Sun", "Website", "Profile", "WordPress",
            "Person", "Bike", "Sun", "Website", "Profile", "WordPress",

    } ;
    int[] gridViewImageId = {
            R.drawable.person, R.drawable.bike, R.drawable.sun, R.drawable.car, R.drawable.umbrealla, R.drawable.flag,
            R.drawable.person, R.drawable.bike, R.drawable.sun, R.drawable.car, R.drawable.umbrealla, R.drawable.flag,
            R.drawable.person, R.drawable.bike, R.drawable.sun, R.drawable.car, R.drawable.umbrealla, R.drawable.flag,

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.book_salonist);

        // Don't forget to insert your App ID below
        //we have inserted Test ID that you can use while testing your App.
        MobileAds.initialize(this, "\n" +
                "       ca-app-pub-8330777012217727~9613351162");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        //Google Admob Interstitial Ad
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("\n" +
                "ca-app-pub-8330777012217727/4049322853");

        //To Load Gogole Admob Interstitial Ad
        mInterstitialAd.loadAd(new AdRequest.Builder().build());

        CustomGridViewActivity adapterViewAndroid = new CustomGridViewActivity(BookSalonist.this, gridViewString, gridViewImageId);
        androidGridView=(GridView)findViewById(R.id.book);
        androidGridView.setAdapter(adapterViewAndroid);
        androidGridView.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> parent, View view,
                                    int i, long id) {
                Toast.makeText(BookSalonist.this, "GridView Item: " + gridViewString[+i], Toast.LENGTH_LONG).show();
            }
        });

    }
}