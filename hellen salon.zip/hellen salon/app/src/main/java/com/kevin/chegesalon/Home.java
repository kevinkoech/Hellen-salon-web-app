package com.kevin.chegesalon;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
//import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.InterstitialAd;
import android.view.View;

public class Home extends AppCompatActivity implements View.OnClickListener {
 
    private AdView mAdView;
    private InterstitialAd mInterstitialAd;

    private CardView Salonist,BeautyProducts,ContactUs,Book,SignUp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);



        // Don't forget to insert your App ID below
        //we have inserted Test ID that you can use while testing your App.
        MobileAds.initialize(this, "\n" +
                "       ca-app-pub-8330777012217727~9613351162");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        //Google Admob Interstitial Ad
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("\n" +
                "ca-app-pub-8330777012217727/4049322853");

        //To Load Gogole Admob Interstitial Ad
        mInterstitialAd.loadAd(new AdRequest.Builder().build());



         Salonist = (CardView)findViewById(R.id.salonist);
         BeautyProducts = (CardView)findViewById(R.id.beauty_products);
         ContactUs = (CardView) findViewById(R.id.contact_us);
         Book = (CardView) findViewById(R.id.book);
        SignUp = (CardView) findViewById(R.id.sign_up1);



        //hairstyle.setOnClickListener(this);
        Book.setOnClickListener(this);
        BeautyProducts.setOnClickListener(this);
        Salonist.setOnClickListener(this);
        ContactUs.setOnClickListener(this);
        SignUp.setOnClickListener(this);





    }

    @Override
    public void onClick(View view) {
        Intent i;
        switch (view.getId()){

           // case R.id.hairstyle: i=new Intent(this,HairStyle.class) ;startActivity(i);break;
            case R.id.salonist: i=new Intent(this,Salonist.class) ;startActivity(i);break;
            //case R.id.braids: i=new Intent(this,Braids.class) ;startActivity(i);break;
            case R.id.beauty_products: i=new Intent(this,BeautyProducts.class) ;startActivity(i);break;
            case R.id.book: i=new Intent(this,BookSalonist.class) ;startActivity(i);break;
            case R.id.contact_us: i=new Intent(this,Contact.class) ;startActivity(i);break;
            case R.id.sign_up1: i=new Intent(this,SignUp.class) ;startActivity(i);break;


     default:break;

        }

    }
}
