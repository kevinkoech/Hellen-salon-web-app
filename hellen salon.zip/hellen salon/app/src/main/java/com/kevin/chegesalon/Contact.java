package com.kevin.chegesalon;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.kevin.chegesalon.R;

public class Contact extends Activity {
    private AdView mAdView;
    private InterstitialAd mInterstitialAd;

    private WebView webView;

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contact);

        // Don't forget to insert your App ID below
        //we have inserted Test ID that you can use while testing your App.
        MobileAds.initialize(this, "\n" +
                "       ca-app-pub-8330777012217727~9613351162");
        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);


        //Google Admob Interstitial Ad
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("\n" +
                "ca-app-pub-8330777012217727/4049322853");

        //To Load Gogole Admob Interstitial Ad
        mInterstitialAd.loadAd(new AdRequest.Builder().build());

        webView = (WebView) findViewById(R.id.webView1);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.loadUrl(
                "https://mwenyeji.com/contactus");


        webView.setWebViewClient(new WebViewClient() {

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, String url) {
                view.loadUrl(url);
                return true;
            }
        });
    }}